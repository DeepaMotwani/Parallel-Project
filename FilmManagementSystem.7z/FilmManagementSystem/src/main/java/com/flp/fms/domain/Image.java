package com.flp.fms.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Image {
	@Id
	private int id;
	private String imageURL;
	private Date createDate;
	private Date deleteDate;
	@ManyToOne
	private Album album;
	
	
	public Image(int id, String imageURL, Date createDate, Date deleteDate) {
		super();
		this.id = id;
		this.imageURL = imageURL;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public Image() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
}
