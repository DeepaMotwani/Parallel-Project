package com.flp.fms.dao;

import java.util.List;

import com.flp.fms.domain.Actor;

public class ActorDAOImpl implements IActorDAO{

	public Actor addActor(Actor actor) {
		return null;
	}

	public List<Actor> findActorByName(String name) {
		return null;
	}

	public String deleteeActor(Actor actor) {
		return null;
	}

	public Actor updateActor(Actor actor) {
		return null;
	}

	public List<Actor> findActorByGender(String gender) {
		return null;
	}

}
