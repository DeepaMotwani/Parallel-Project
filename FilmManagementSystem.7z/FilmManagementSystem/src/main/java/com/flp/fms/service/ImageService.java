package com.flp.fms.service;

import java.util.Date;

import javax.persistence.EntityManager;

import com.flp.fms.domain.Image;

public class ImageService {
protected EntityManager em;
	
	public ImageService(EntityManager em){
		this.em=em;
	}
	
	
}
