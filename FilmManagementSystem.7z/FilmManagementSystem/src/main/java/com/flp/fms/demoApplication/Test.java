//package com.flp.fms.demoApplication;
//
//import java.util.List;
//
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.Persistence;
//
//import com.flp.fms.domain.Album;
//import com.flp.fms.domain.Film;
//import com.flp.fms.domain.Image;
//
//
//
//public class Test {
//
//
//	public static void main(String[] args) {
//EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
//		
//		EntityManager em = emf.createEntityManager();
//		 Service service = new Service(em);
//		em.getTransaction().begin();
//		Film film = new Film();
//		film.setId(1);
//		em.getTransaction().commit();
//		em.persist(film);
//		System.out.println("Persisted "+film);
//		em.close();
//		emf.close();
//		
//	}
//	
//	
//
//}
